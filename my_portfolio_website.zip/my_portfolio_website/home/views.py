from django.shortcuts import render
from .forms import UserForm
from .models import Users
from django.core import validators
from django.http import HttpResponseRedirect
from django.db import connection

#PORTFOLIO-FUNCTIONS

def portfolio(request):

    return render(request, 'index.html')

def services_frontend(request):

    return render(request, 'info_frontend.html')

def services_backend(request):

    return render(request, 'info_backend.html')

def services_api(request):

    return render(request, 'info_api.html')

def services_database(request):

    return render(request, 'info_database.html')

def services_software(request):

    return render(request, 'info_software.html')

def services_full_stack(request):

    return render(request, 'info_full_stack.html')





# ----------------------------------------------------------------------------------------------

# This function will show home page
def Show_base(request):

    return render(request, 'home/base.html')


# This function will add records and show them as well
def Show_add(request):
    if request.method=='POST':
        form = UserForm(request.POST)
        if form.is_valid():
            nm = form.cleaned_data['name']
            eml = form.cleaned_data['email']
            psw = form.cleaned_data['password'] 
            assigndata = Users(name=nm, email=eml, password=psw)
            assigndata.save()
            
            return HttpResponseRedirect('/add_stu/')        
    else:
        form = UserForm()
    stu= Users.objects.all()
    return render(request, 'home/add_show.html',{'stu':stu, 'form':form})


# UPDATE-DATA FUNCTION
def Show_update(request,id):
    if request.method == 'POST':
        data = Users.objects.get(pk=id)
        print(data)
        form = UserForm(request.POST, instance=data)
        if form.is_valid():
            form.save()
   
    else:
        form = UserForm(pk=id)
    return render(request, 'home/add_show.html',)



#DELETE DATA FUNCTION
def delete_User(request, id):
    if request.method=='POST':
        user_id = Users.objects.get(pk=id)
        user_id.delete()
        
    return HttpResponseRedirect('/add_stu/')


# EDIT DATA FUNCTION
def edit_User(request, id):

    if request.method=='POST':
        data = Users.objects.get(pk=id)
        form = UserForm(request.POST , instance=data)
        if form.is_valid():
            form.save()
        return HttpResponseRedirect('/add_stu/')

    else:
        data = Users.objects.get(pk=id)
        form = UserForm(instance=data)
    return render(request, 'home/edit_student.html', {'id':id,'form':form})
            


