from django.urls import path
from home import views

urlpatterns = [
    path('base/', views.Show_base, name='base'),
    path('add_stu/', views.Show_add, name='add'),
    path('update_stu/', views.Show_update, name='update'),
    path('delete_stu/<int:id>/', views.delete_User, name='delete'),
    path('edit_stu/<int:id>/', views.edit_User, name='edit'),

]
